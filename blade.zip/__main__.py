#!/usr/bin/env python


import sys
from blade_main import main


if __name__ == "__main__":
    main(sys.argv[0])
