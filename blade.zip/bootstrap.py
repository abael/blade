"""
 Copyright (c) 2013 Tencent Inc.
 All rights reserved.
 Author: Feng chen <phongchen@tencent.com>
"""

import sys
import os.path

sys.path.insert(0, ".")
import blade_main

blade_main.main(".")

